# Universal WMMT6 Client Configurator

This folder configures a legally obtained Japanese WMMT6 1.03.04 client to use a separate Project Asakura Bayshore server. The client computer does not need Node.js, PostgreSQL, or a full Bayshore server checkout.

Use the **v1.6.0 client setup ZIP** from the repository's `releases` folder. Extract it separately on each PC, close the game, and run `Configure-Client.bat` as administrator. Choose different cabinet numbers (1, 2, 3, or 4), then launch with `WMMT6-Launch.bat` beside TeknoParrot. Upgrading users must rerun setup on each PC to install the fixes.

v1.6.0 fixes the cabinet selector: selection 1 writes game `mPcbId=0`, selection 2 writes `mPcbId=1`, and so on. Previous packages only changed AMAuth `netID`, leaving every game at cabinet 2. Setup now changes both and preserves existing calibration, credits, audio, and other Service settings. Esc closes the game normally without the CMD launch-failed message; native crashes remain failures with diagnostics.

## What setup asks for

1. The Bayshore server IPv4 address, such as `192.168.0.25`.
2. A unique drive cabinet number from 1 through 4.
3. The client's WMMT6 `wmn6r.exe`.
4. The client's `TeknoParrotUi.exe`.

The server address is validated before setup continues. The active client IPv4 address and default gateway are detected automatically unless explicit values are placed in `client-config.json`.

## Required assets

The release ZIP includes four verified Bayshore-specific assets: `bngrw.dll`, `setting.lua.gz`, and the certificate/key pair. It does not distribute or overwrite `OpenParrot64.dll`; setup preserves the version supplied by the selected TeknoParrot installation. Setup checks the entire client, every asset, AMCUS configuration, the existing WMMT6 profile, client identity, and network adapter before modifying anything.

Every SHA-256 listed in [assets/README.md](assets/README.md) is verified before changing the client. No runtime file, certificate, or key needs to be selected separately when using the release ZIP.

The WMMT6 game folder must already contain its original `AMCUS` directory, including `AMAuthd.exe`, `AMConfig.ini`, `iauthdll.dll`, and `MuchaBin\muchacd.exe`.
The x64 Microsoft Visual C++ 2010 SP1 runtime (`MSVCR100.dll`) is also required by `iauthdll.dll`; setup checks it during preflight.

## Run

1. Close WMMT6 and TeknoParrot.
2. Right-click `Configure-Client.bat` and select **Run as administrator**.
3. Enter the Bayshore server IPv4 address.
4. Select the correct `wmn6r.exe` and `TeknoParrotUi.exe` when prompted.
5. Wait for `WMMT6 client configuration completed successfully`.
6. Start Bayshore and the single server-side MaxiTerminal.
7. Run `WMMT6-Launch.bat` from the selected TeknoParrot root.

## What is configured

- the existing TeknoParrot-supplied OpenParrot runtime, preserved unchanged;
- the verified OpenBanapass client file;
- WMMT6 network certificates;
- Shift-JIS-safe `AMConfig.ini` changes for MUCHA;
- `WritableConfig.ini` with a unique drive serial;
- automatic matching of AMAuth `serialID` to the `280811...` auth identity embedded in OpenParrot;
- `WritableConfig.ini` with a unique cabinet `netID` from 1 through 4;
- the matching game Service cabinet number in `TP\setting.lua.gz` (`mPcbId` 0 through 3);
- a persistent, unique client/card identity;
- the existing WMMT6 user profile, automatically corrected with the selected game path, single-executable launching, terminal emulation, card access, the active client adapter, the real router, `WhiteScreenFix=1`, and `Windowed=0`;
- removal of obsolete `WMMT6-Bayshore.xml` copies that appeared as a second `Metadata Missing` game;
- Windows hosts entries for ALL.Net;
- the `225.0.0.1/32` multicast route on the active adapter;
- scoped Windows Firewall rules;
- `iauthdll.dll` registration;
- `WMMT6-Launch.bat` and its helper/config beside `TeknoParrotUi.exe`.

The launcher starts `AMAuthd.exe` directly so OpenParrot is never injected into it, then launches the existing WMMT6 profile through TeknoParrot. The required OpenParrot White Screen Fix stays enabled to prevent flashing, while its unstable `Windowed` option stays disabled. After the game creates its window, the launcher removes the border and fits a centered 16:9 image inside the current monitor. Non-16:9 displays get black bars instead of a stretched picture. Windows display resolution is never changed and no extra DLL is injected. The launcher validates the profile and server first, writes a launch log, and copies a recent WER report when the game exits unexpectedly.

Setup backs up and removes the obsolete independent `WMMT6-Borderless.*` helper from the selected TeknoParrot root. Its aspect-preserving behavior is now built into `WMMT6-Launch.bat`, avoiding two launchers competing for AMAuth or the game window.

Existing files are backed up under `client-setup\backups` before replacement. Do not copy `generated-client-identity.json` or `card.ini` between active cabinets.

For simultaneous play, every computer must use a different cabinet number: cabinet 1 uses `netID=1` and `mPcbId=0`, cabinet 2 uses `netID=2` and `mPcbId=1`, and so on. Check the game Service menu shows the number selected in setup. A different card ID or drive serial does not replace this requirement. If two clients were configured with an older package, update the package and rerun `Configure-Client.bat` on each computer, selecting a different cabinet number. Only one MaxiTerminal instance should run for the venue.

If versus starts but returns to Story Mode selection, check duplicate cabinet numbers and the connection between the player PCs. Use the same LAN and Ethernet for the most reliable test. Wi-Fi multicast loss, latency spikes, guest networks, and client isolation can interrupt versus even while Bayshore and MaxiTerminal remain healthy. The server terminal relay carries terminal heartbeats only; it cannot repair a dropped race connection. Run the server package's `Check-Multiplayer-Network.bat` on each PC against the other PC to inspect packet loss and latency. ICMP replies alone do not prove game UDP traffic works.

The supported OpenParrot source contains an AMAuth/terminal identity of `280811990002` and a separate drive-dongle identity beginning with `280813`. `AMCUS\WritableConfig.ini` requires the `280811...` identity. Setup detects that embedded value and writes it automatically. Using `280813...` causes startup error E0517 after ALL.Net and before MUCHA. Leave `DriveSerial` as `AUTO` unless diagnosing a custom build; an explicit value is rejected when it differs from the DLL.

MaxiTerminal is not installed on each client. Normally, one compatible MaxiTerminal instance runs on the server or another designated computer on the same LAN.

## Supported version

This package accepts only the known WMMT6 1.03.04 `wmn6r.exe` hash. It does not support WMMT6R or WMMT6RR.
The configurator refuses the known crashing custom OpenParrot hashes from v1.1.7-v1.2.0. Restore OpenParrot with TeknoParrot's updater or a clean TeknoParrot backup before running the current package.
The package never scans for or automatically selects a ROM when `GamePath` is `SELECT` (the default).

The multicast route is created as an on-link route (`NextHop 0.0.0.0`). Setup
uses the modern Windows networking command first and automatically falls back
to persistent `netsh` or `route.exe` syntax on Windows versions that reject it.

`iauthdll.dll` is registered from its AMCUS working directory. If Windows
rejects re-registration, setup accepts an existing COM registration only when
the registered DLL exists and its SHA-256 matches the selected client's DLL.
