[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$principal = [Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script from an elevated PowerShell window.'
}

$tcpName = 'Bayshore WMMT6 LAN TCP'
$udpName = 'Bayshore WMMT6 LAN Multicast'
$root = Split-Path -Parent $PSScriptRoot
$terminalExe = (Resolve-Path (Join-Path $root 'bin\MaxiTerminal\MaxiTerminal.exe')).Path
$config = Get-Content -LiteralPath (Join-Path $root 'config.json') -Raw | ConvertFrom-Json
$serverIp = $config.serverIp
$lanAddress = Get-NetIPAddress -AddressFamily IPv4 -IPAddress $serverIp -ErrorAction Stop | Where-Object { $_.AddressState -eq 'Preferred' } | Select-Object -First 1
if (-not $lanAddress) { throw "LAN address $serverIp is not active." }

# Windows may create Block rules when the first firewall prompt is declined.
# Remove only rules associated with this reviewed MaxiTerminal executable.
$terminalFilters = Get-NetFirewallApplicationFilter -ErrorAction SilentlyContinue | Where-Object { $_.Program -eq $terminalExe }
foreach ($filter in $terminalFilters) {
    Get-NetFirewallRule -AssociatedNetFirewallApplicationFilter $filter -ErrorAction SilentlyContinue |
        Where-Object { $_.Action -eq 'Block' } |
        Remove-NetFirewallRule
}

Get-NetFirewallRule -DisplayName $tcpName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
Get-NetFirewallRule -DisplayName $udpName -ErrorAction SilentlyContinue | Remove-NetFirewallRule
New-NetFirewallRule -DisplayName $tcpName -Direction Inbound -Action Allow -Protocol TCP -LocalPort 80,10082,9002 -RemoteAddress LocalSubnet -Profile Any | Out-Null
New-NetFirewallRule -DisplayName $udpName -Direction Inbound -Action Allow -Program $terminalExe -Protocol UDP -LocalPort 50765 -RemoteAddress LocalSubnet -Profile Any | Out-Null

$route = Get-NetRoute -DestinationPrefix '225.0.0.1/32' -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.InterfaceIndex -eq $lanAddress.InterfaceIndex }
if (-not $route) {
    & route.exe -p ADD 225.0.0.1 MASK 255.255.255.255 $serverIp METRIC 1 IF $lanAddress.InterfaceIndex | Out-Host
    if ($LASTEXITCODE -ne 0) { throw 'Failed to add the WMMT6 multicast route.' }
}

Write-Host "LAN-only rules added; multicast 225.0.0.1 is bound to $($lanAddress.InterfaceAlias) ($serverIp)."
