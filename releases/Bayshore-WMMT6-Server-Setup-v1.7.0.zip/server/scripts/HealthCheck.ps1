[CmdletBinding()]
param()

$ErrorActionPreference = 'SilentlyContinue'
$root = Split-Path -Parent $PSScriptRoot
$config = Get-Content -LiteralPath (Join-Path $root 'config.json') -Raw | ConvertFrom-Json
$pgReady = Join-Path $root '.runtime\pgsql\bin\pg_isready.exe'
& $pgReady -h 127.0.0.1 -p 5432 -q
$dbOk = $LASTEXITCODE -eq 0

try {
    $response = (& curl.exe -k -sS --fail --max-time 5 "https://127.0.0.1:9002/healthz" | ConvertFrom-Json)
    $serviceOk = $response.status -eq 'ready'
} catch {
    $serviceOk = $false
}

$ports = [ordered]@{}
foreach ($port in 80, 10082, 9002) {
    $client = [System.Net.Sockets.TcpClient]::new()
    try {
        $client.Connect('127.0.0.1', $port)
        $ports["tcp_$port"] = $true
    } catch {
        $ports["tcp_$port"] = $false
    } finally {
        $client.Dispose()
    }
}
$terminal = Get-Process -Name MaxiTerminal -ErrorAction SilentlyContinue | Select-Object -First 1
$terminalUdp = $null
if ($terminal) {
    $terminalUdp = Get-NetUDPEndpoint -LocalPort 50765 -ErrorAction SilentlyContinue | Where-Object { $_.OwningProcess -eq $terminal.Id } | Select-Object -First 1
}

[ordered]@{
    status = if ($dbOk -and $serviceOk -and -not ($ports.Values -contains $false)) { 'ready' } else { 'not_ready' }
    lanIp = $config.serverIp
    database = $dbOk
    gameService = $serviceOk
    maxiTerminal = [bool]$terminal
    terminalUdp50765 = [bool]$terminalUdp
    listeners = $ports
} | ConvertTo-Json -Depth 4
