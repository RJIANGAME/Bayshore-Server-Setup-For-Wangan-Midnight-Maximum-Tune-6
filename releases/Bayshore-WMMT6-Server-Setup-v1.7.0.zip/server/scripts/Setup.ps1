[CmdletBinding()]
param(
    [string]$ServerIp = '192.168.0.25',
    [int]$PostgresPort = 5432
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$runtime = Join-Path $root '.runtime'
$pgRoot = Join-Path $runtime 'pgsql'
$pgBin = Join-Path $pgRoot 'bin'
$pgData = Join-Path $root '.data\postgres'
$archive = Join-Path $runtime 'postgresql-17.11-1-windows-x64-binaries.zip'
$downloadUrl = 'https://sbp.enterprisedb.com/getfile.jsp?fileid=1260427'
$envFile = Join-Path $root '.env'
$configFile = Join-Path $root 'config.json'

function Get-EnvValue([string]$Name) {
    $line = Get-Content -LiteralPath $envFile | Where-Object { $_ -match "^$([regex]::Escape($Name))=" } | Select-Object -First 1
    if (-not $line) { return $null }
    return $line.Substring($line.IndexOf('=') + 1)
}

$nodeVersion = (& node --version).TrimStart('v').Split('.')[0]
if ([int]$nodeVersion -lt 20) { throw 'Node.js 20 or newer is required.' }

New-Item -ItemType Directory -Force -Path $runtime, (Join-Path $root '.data') | Out-Null
if (-not (Test-Path -LiteralPath (Join-Path $pgBin 'pg_ctl.exe'))) {
    if (-not (Test-Path -LiteralPath $archive)) {
        Write-Host 'Downloading PostgreSQL 17 portable binaries...'
        & curl.exe -L --fail --retry 3 -A 'Mozilla/5.0' -o $archive $downloadUrl
        if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL download failed.' }
    }
    Write-Host 'Extracting PostgreSQL...'
    Expand-Archive -LiteralPath $archive -DestinationPath $runtime -Force
}

if (-not (Test-Path -LiteralPath $envFile)) {
    $alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    $dbPassword = -join (1..40 | ForEach-Object { $alphabet[(Get-Random -Maximum $alphabet.Length)] })
    @(
        "POSTGRES_URL=postgresql://bayshore:$dbPassword@127.0.0.1:$PostgresPort/bayshore"
        "POSTGRES_PASSWORD=$dbPassword"
        "POSTGRES_PORT=$PostgresPort"
        'ALLNET_PORT=80'
        'MUCHA_PORT=10082'
        'SERVICE_PORT=9002'
        'API_PORT=9003'
        'OPENTELEMETRY_ENABLED=false'
        'OPENTELEMETRY_OTLP_URI=disregard-this'
    ) | Set-Content -LiteralPath $envFile -Encoding ascii
} else {
    $dbPassword = Get-EnvValue 'POSTGRES_PASSWORD'
    if (-not $dbPassword) { throw '.env is missing POSTGRES_PASSWORD.' }
}

if (-not (Test-Path -LiteralPath $configFile)) {
    $config = [ordered]@{
        placeId = 'JPN0123'
        shopName = 'Bayshore LAN'
        shopNickname = 'Bayshore'
        regionId = 1
        country = 'JPN'
        regionName = 'JPN0123'
        serverIp = $ServerIp
        gameOptions = [ordered]@{
            grantFullTuneTicketToNewUsers = 5
            giftCarsFullyTuned = 0
            scratchEnabled = 1
            scratchType = 0
            giveMeterReward = 0
            newCardsBanned = 0
            revisionCheck = 1
            enableScreenshot = 0
            ghostTrailAutodeleteDays = 0
        }
    }
    $json = $config | ConvertTo-Json -Depth 5
    [IO.File]::WriteAllText($configFile, $json, [Text.UTF8Encoding]::new($false))
} else {
    $config = Get-Content -LiteralPath $configFile -Raw | ConvertFrom-Json
    $config.serverIp = $ServerIp
    $json = $config | ConvertTo-Json -Depth 10
    [IO.File]::WriteAllText($configFile, $json, [Text.UTF8Encoding]::new($false))
}

if (-not (Test-Path -LiteralPath (Join-Path $pgData 'PG_VERSION'))) {
    New-Item -ItemType Directory -Force -Path $pgData | Out-Null
    $passwordFile = Join-Path $root '.data\pg-password.tmp'
    try {
        Set-Content -LiteralPath $passwordFile -Value $dbPassword -Encoding ascii -NoNewline
        & (Join-Path $pgBin 'initdb.exe') -D $pgData -U postgres -E UTF8 --auth-host=scram-sha-256 --auth-local=trust --pwfile=$passwordFile
        if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL initialization failed.' }
    } finally {
        Remove-Item -LiteralPath $passwordFile -Force -ErrorAction SilentlyContinue
    }
    Add-Content -LiteralPath (Join-Path $pgData 'postgresql.conf') -Encoding ascii -Value "`nlisten_addresses = '127.0.0.1'`nport = $PostgresPort`n"
}

$env:PGPASSWORD = $dbPassword
$pgReady = Join-Path $pgBin 'pg_isready.exe'
& $pgReady -h 127.0.0.1 -p $PostgresPort -q
if ($LASTEXITCODE -ne 0) {
    & (Join-Path $pgBin 'pg_ctl.exe') -D $pgData -l (Join-Path $root '.data\postgres.log') -o "-h 127.0.0.1 -p $PostgresPort" start
    if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL failed to start.' }
}

$roleExists = & (Join-Path $pgBin 'psql.exe') -h 127.0.0.1 -p $PostgresPort -U postgres -d postgres -tAc "SELECT 1 FROM pg_roles WHERE rolname='bayshore'"
if (($roleExists | Out-String).Trim() -ne '1') {
    & (Join-Path $pgBin 'psql.exe') -h 127.0.0.1 -p $PostgresPort -U postgres -d postgres -v ON_ERROR_STOP=1 -c "CREATE ROLE bayshore LOGIN PASSWORD '$dbPassword'"
}
$dbExists = & (Join-Path $pgBin 'psql.exe') -h 127.0.0.1 -p $PostgresPort -U postgres -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname='bayshore'"
if (($dbExists | Out-String).Trim() -ne '1') {
    & (Join-Path $pgBin 'createdb.exe') -h 127.0.0.1 -p $PostgresPort -U postgres -O bayshore bayshore
}
Remove-Item Env:PGPASSWORD -ErrorAction SilentlyContinue

Push-Location $root
try {
    npm ci
    if ($LASTEXITCODE -ne 0) { throw 'npm install failed.' }
    npm run prisma-generate
    if ($LASTEXITCODE -ne 0) { throw 'Prisma generation failed.' }
    npx prisma migrate deploy
    if ($LASTEXITCODE -ne 0) { throw 'Database migration failed.' }
    npm run build
    if ($LASTEXITCODE -ne 0) { throw 'Bayshore build failed.' }
} finally {
    Pop-Location
}

Write-Host "Bayshore setup complete for LAN IP $ServerIp."
