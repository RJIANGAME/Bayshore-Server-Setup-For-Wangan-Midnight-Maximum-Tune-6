[CmdletBinding()]
param([switch]$Background)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$pgBin = Join-Path $root '.runtime\pgsql\bin'
$pgData = Join-Path $root '.data\postgres'
$dataDir = Join-Path $root '.data'
$pidFile = Join-Path $dataDir 'bayshore.pid'

if (-not (Test-Path -LiteralPath (Join-Path $root '.env'))) { throw 'Run scripts\Setup.ps1 first.' }
New-Item -ItemType Directory -Force -Path $dataDir | Out-Null

& (Join-Path $pgBin 'pg_isready.exe') -h 127.0.0.1 -p 5432 -q
if ($LASTEXITCODE -ne 0) {
    & (Join-Path $pgBin 'pg_ctl.exe') -D $pgData -l (Join-Path $dataDir 'postgres.log') -o '-h 127.0.0.1 -p 5432' start
    if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL failed to start.' }
}

if (Test-Path -LiteralPath $pidFile) {
    $existingPid = [int](Get-Content -LiteralPath $pidFile -Raw)
    if (Get-Process -Id $existingPid -ErrorAction SilentlyContinue) {
        & curl.exe --insecure --silent --fail --max-time 3 'https://127.0.0.1:9002/readyz' *> $null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Bayshore is already running (PID $existingPid)."
            exit 0
        }
    }
}

# Recover from a stale PID file after an interrupted or overlapping launcher.
# Only adopt a listener after its Bayshore readiness endpoint succeeds.
$servicePort = 9002
$servicePortLine = Get-Content -LiteralPath (Join-Path $root '.env') |
    Where-Object { $_ -match '^SERVICE_PORT=(\d+)$' } |
    Select-Object -First 1
if ($servicePortLine -match '^SERVICE_PORT=(\d+)$') {
    $servicePort = [int]$Matches[1]
}
$existingListener = Get-NetTCPConnection -LocalPort $servicePort -State Listen -ErrorAction SilentlyContinue |
    Select-Object -First 1
if ($existingListener) {
    & curl.exe --insecure --silent --fail --max-time 3 "https://127.0.0.1:$servicePort/readyz" *> $null
    if ($LASTEXITCODE -eq 0) {
        Set-Content -LiteralPath $pidFile -Value $existingListener.OwningProcess -Encoding ascii
        Write-Host "Bayshore is already running (PID $($existingListener.OwningProcess)); repaired stale PID file."
        exit 0
    }
}

# WMMT6/Bayshore ships a legacy certificate that current Node/OpenSSL releases
# reject at their default security level. Scope the compatibility setting to
# this process only; never expose this legacy service directly to the internet.
$process = Start-Process -FilePath (Get-Command node).Source -ArgumentList '--tls-cipher-list=DEFAULT@SECLEVEL=0', 'dist' -WorkingDirectory $root -RedirectStandardOutput (Join-Path $dataDir 'bayshore.out.log') -RedirectStandardError (Join-Path $dataDir 'bayshore.err.log') -WindowStyle Hidden -PassThru
Set-Content -LiteralPath $pidFile -Value $process.Id -Encoding ascii
Start-Sleep -Seconds 2
if ($process.HasExited) {
    throw "Bayshore exited during startup. See .data\bayshore.err.log."
}
Write-Host "Bayshore started (PID $($process.Id))."
