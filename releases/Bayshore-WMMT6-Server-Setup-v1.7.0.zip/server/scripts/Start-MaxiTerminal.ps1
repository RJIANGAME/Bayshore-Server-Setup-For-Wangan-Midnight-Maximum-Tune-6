[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$terminalDir = Join-Path $root 'bin\MaxiTerminal'
$terminalExe = Join-Path $terminalDir 'MaxiTerminal.exe'
$terminalConfig = Join-Path $terminalDir 'config.json'
$expectedHash = 'DF792DE6500F1A9836439535846B12E2391024E98097DE4E7145F29027F262AF'

if (-not (Test-Path -LiteralPath $terminalExe)) { throw "Missing $terminalExe" }
if (-not (Test-Path -LiteralPath $terminalConfig)) { throw "Missing $terminalConfig" }
$actualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $terminalExe).Hash
if ($actualHash -ne $expectedHash) { throw 'MaxiTerminal.exe does not match the reviewed binary hash.' }

$config = Get-Content -LiteralPath $terminalConfig -Raw | ConvertFrom-Json
if ($config.software_revision -ne '10304') { throw 'MaxiTerminal must use WMMT6 revision 10304.' }
if ($config.adapter -eq '0.0.0.0' -or $config.adapter_ip -eq '0.0.0.0') { throw 'Configure a physical LAN address for adapter and adapter_ip.' }

$existing = Get-Process -Name MaxiTerminal -ErrorAction SilentlyContinue | Select-Object -First 1
if ($existing) {
    Write-Host "MaxiTerminal is already running (PID $($existing.Id))."
    exit 0
}

$process = Start-Process -FilePath $terminalExe -WorkingDirectory $terminalDir -PassThru
Start-Sleep -Seconds 2
if ($process.HasExited) { throw 'MaxiTerminal exited during startup.' }
Write-Host "MaxiTerminal started (PID $($process.Id)) for adapter $($config.adapter_ip)."
