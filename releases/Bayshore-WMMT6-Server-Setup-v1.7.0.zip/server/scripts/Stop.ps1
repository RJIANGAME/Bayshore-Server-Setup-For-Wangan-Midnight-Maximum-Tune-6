[CmdletBinding()]
param(
    [switch]$IncludeDatabase,
    [switch]$KeepDatabaseRunning
)

$root = Split-Path -Parent $PSScriptRoot
$pidFile = Join-Path $root '.data\bayshore.pid'
Get-Process -Name MaxiTerminal -ErrorAction SilentlyContinue | Stop-Process -ErrorAction SilentlyContinue
if (Test-Path -LiteralPath $pidFile) {
    $serverPid = [int](Get-Content -LiteralPath $pidFile -Raw)
    Stop-Process -Id $serverPid -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue
}
if ($IncludeDatabase -and -not $KeepDatabaseRunning) {
    $pgCtl = Join-Path $root '.runtime\pgsql\bin\pg_ctl.exe'
    if (Test-Path -LiteralPath $pgCtl) {
        $pgData = Join-Path $root '.data\postgres'
        & $pgCtl -D $pgData status *> $null
        if ($LASTEXITCODE -eq 0) {
            & $pgCtl -D $pgData stop -m fast
            if ($LASTEXITCODE -ne 0) { throw 'PostgreSQL failed to stop.' }
        }
    }
}
if ($IncludeDatabase -and -not $KeepDatabaseRunning) {
    Write-Host 'Bayshore, MaxiTerminal, and PostgreSQL stopped.'
} else {
    Write-Host 'Bayshore and MaxiTerminal stopped; PostgreSQL remains available.'
}
